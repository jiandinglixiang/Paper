import React, { Component } from 'react'
import { Button, Icon, InputItem, List, NavBar, WhiteSpace } from 'antd-mobile'
import style from './index.module.scss'
import { createForm } from 'rc-form'

const From = createForm()(function (props) {
  const { getFieldProps } = props.form
  return <List renderHeader={() => '注册'}>
    <InputItem
      {...getFieldProps('phone')}
      type="phone"
      placeholder="188 8888 8888"
    >手机号码</InputItem>
    <InputItem
      {...getFieldProps('password')}
      type="password"
      placeholder="输入密码"
    >密码</InputItem>
    <InputItem
      {...getFieldProps('password2')}
      type="password2"
      placeholder="再次输入密码"
    >密码</InputItem>
  </List>
})

class Setting extends Component {
  state = {
    hasError: false,
    value: '',
  }
  submitSearch = () => {
    console.log(this.state.searchVal)
  }
  onChange = (val) => {
    this.setState({ value: val })
  }
  onSubmit = (e) => {
    e.preventDefault()
    this.props.form.validateFields((error, values) => {
      if (!error) {
        console.log('ok', values)
      } else {
        console.log('error', error, values)
      }
    })
  }

  render () {
    return (<div className={style['app-page']}>
      <NavBar
        mode="light"
        icon={<Icon type="left"/>}
        onLeftClick={() => {
          this.props.history.goBack()
        }}>注册</NavBar>
      <From/>
      <WhiteSpace/>
      <Button type="warning">注册提交</Button>
    </div>)
  }
}

export default Setting
